# Online Banking and Broker for Investment

Generated project structure for deployment.